package br.com.senac.game_library;
import Telas.*;
public class Game_Library {
    public static void main(String[] args) {
      TelaInicial tela = new TelaInicial();
      tela.setVisible(true);
    }
}
